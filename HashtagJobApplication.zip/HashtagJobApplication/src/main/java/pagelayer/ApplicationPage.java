package pagelayer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import testbase.TestBase;

public class ApplicationPage extends TestBase {
	
	public ApplicationPage()             //constructor
	{
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//input[@name='name']")                   
	private WebElement txtbox_name;
	
	@FindBy(xpath="//input[@name='email']")
	private WebElement txtbox_email;
	
	@FindBy(xpath="//input[@name='phone']")
	private WebElement txtbox_phone;
	
	@FindBy(xpath="//input[@name='inputFile']")
	private WebElement txtbox_inputFile;
	
	@FindBy(xpath="//input[@name='description']")
	private WebElement txtbox_description;
	
	



	
	@FindBy(xpath="//button[text()='Apply Now']")
	private WebElement btn_apply;
	
	//-------------Action method-----------
	
	public void enterName(String name)
	{
		txtbox_email.sendKeys(name);
	}
	
	public void enterEmailID(String email)
	{
		txtbox_email.sendKeys(email);
	}
	
	public void enterPhone(String phone)
	{
		txtbox_phone.sendKeys(phone);
	}
	
	public void inputFile(String inputFile)
	{
		WebElement fileUploadElement = driver.findElement(By.id("inputFile"));
		String resumeFilePath = "C:\\Users\\prita\\Desktop\\New folder\\Pratibha Ahirrao Resume (1).pdf";
		fileUploadElement.sendKeys(resumeFilePath);

	}
	
	public void enterDescription(String description)
	{
		txtbox_description.sendKeys(description);
	}
	
	public void clickOnApplyButton()
	{
		btn_apply.click();
	}
	
	public String geturl()
	{
		String curl = driver.getCurrentUrl();
		return curl;
	
    }

}
