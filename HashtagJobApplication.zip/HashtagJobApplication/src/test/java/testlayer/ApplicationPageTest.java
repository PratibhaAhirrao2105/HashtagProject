package testlayer;

import org.testng.annotations.Test;

import pagelayer.ApplicationPage;
import testbase.TestBase;

public class ApplicationPageTest extends TestBase {
	
	@Test
	public void testSuccessfulApplicationSubmission() throws InterruptedException {
        
        
        ApplicationPage applicationPage = new ApplicationPage();
        applicationPage.enterName("Pratibha Ahirrao");
        Thread.sleep(3000);
        applicationPage.enterEmailID("spratibha1112@gmail.com");
        Thread.sleep(3000);
        applicationPage.enterPhone("9665394088");
        Thread.sleep(3000);
        applicationPage.inputFile("Pratibha Ahirrao Resume (1)");
        Thread.sleep(3000);
        applicationPage.enterDescription("I am Intrested");
        Thread.sleep(3000);
        applicationPage.clickOnApplyButton();
        Thread.sleep(3000);
        
       
        
        
        
    }

}
